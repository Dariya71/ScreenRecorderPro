package com.example.screenrecorder

import android.app.*
import android.content.*
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
 private val projectionManager by lazy { getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager }
 private val requestCode = 201
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
  val layout = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(48,80,48,32); gravity=Gravity.CENTER }
  val title=TextView(this).apply { text="Screen Recorder Pro"; textSize=26f; gravity=Gravity.CENTER }
  val info=TextView(this).apply { text="1080p / 30fps • MP4 • Floating stop button\nAndroid will ask for screen capture consent each time."; gravity=Gravity.CENTER; setPadding(0,30,0,30) }
  val start=Button(this).apply { text="Start recording"; setOnClickListener { begin() } }
  val stop=Button(this).apply { text="Stop recording"; setOnClickListener { startService(Intent(this@MainActivity,RecorderService::class.java).setAction("STOP")) } }
  layout.addView(title); layout.addView(info); layout.addView(start); layout.addView(stop); setContentView(layout)
 }
 private fun begin() {
  if (!Settings.canDrawOverlays(this)) { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); Toast.makeText(this,"Allow display over other apps, then tap Start again",Toast.LENGTH_LONG).show(); return }
  startActivityForResult(projectionManager.createScreenCaptureIntent(),requestCode)
 }
 @Deprecated("Deprecated in Android API")
 override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) { super.onActivityResult(requestCode,resultCode,data)
  if(requestCode==this.requestCode && resultCode==RESULT_OK && data!=null) {
   val intent=Intent(this,RecorderService::class.java).setAction("START").putExtra("resultCode",resultCode).putExtra("resultData",data)
   startForegroundService(intent); moveTaskToBack(true)
  }
 }
}
