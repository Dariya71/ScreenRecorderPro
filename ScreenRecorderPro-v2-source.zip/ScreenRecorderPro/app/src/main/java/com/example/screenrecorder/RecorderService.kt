package com.example.screenrecorder

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.provider.MediaStore
import android.view.*
import android.widget.TextView
import java.io.FileDescriptor

class RecorderService : Service() {
 private var projection:MediaProjection?=null
 private var recorder:MediaRecorder?=null
 private var display:android.hardware.display.VirtualDisplay?=null
 private var output:android.net.Uri?=null
 private var descriptor:android.os.ParcelFileDescriptor?=null
 private var wm:WindowManager?=null
 private var bubble:TextView?=null
 private var recording=false
 private var paused=false
 private var callback:MediaProjection.Callback?=null
 override fun onBind(intent:Intent?)=null
 override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int {
  when(intent?.action) { "STOP" -> stopRecording(); "PAUSE" -> pauseRecording(); "RESUME" -> resumeRecording(); "START" -> if(!recording) {
   val code=intent.getIntExtra("resultCode",Activity.RESULT_CANCELED)
   @Suppress("DEPRECATION") val data=if(Build.VERSION.SDK_INT>=33) intent.getParcelableExtra("resultData",Intent::class.java) else intent.getParcelableExtra<Intent>("resultData")
   if(code==Activity.RESULT_OK && data!=null) { startForegroundNotification(); try { beginRecording(code,data) } catch(e:Exception) { android.util.Log.e("Recorder","Recording failed",e); stopRecording() } } else stopSelf()
  } }
  return START_NOT_STICKY
 }
 private fun startForegroundNotification() {
  val channel="recording"
  val manager=getSystemService(NOTIFICATION_SERVICE) as NotificationManager
  manager.createNotificationChannel(NotificationChannel(channel,"Screen recording",NotificationManager.IMPORTANCE_LOW))
  val stopIntent=PendingIntent.getService(this,1,Intent(this,RecorderService::class.java).setAction("STOP"),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
  val notification=Notification.Builder(this,channel).setSmallIcon(android.R.drawable.presence_video_online).setContentTitle("Screen recording").setContentText("Recording screen • Tap Stop to save").setOngoing(true).addAction(android.R.drawable.ic_media_pause,"Stop",stopIntent).build()
  startForeground(10,notification)
 }
 private fun beginRecording(resultCode:Int,data:Intent) {
  val values=android.content.ContentValues().apply { put(MediaStore.Video.Media.DISPLAY_NAME,"Screen_${System.currentTimeMillis()}.mp4"); put(MediaStore.Video.Media.MIME_TYPE,"video/mp4"); put(MediaStore.Video.Media.RELATIVE_PATH,"Movies/ScreenRecorderPro"); put(MediaStore.Video.Media.IS_PENDING,1) }
  output=contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,values) ?: error("Could not create video")
  descriptor=contentResolver.openFileDescriptor(output!!,"w") ?: error("Could not open video")
  val dm=resources.displayMetrics
  val maxSide=1920f
  val factor=minOf(1f,maxSide/maxOf(dm.widthPixels,dm.heightPixels))
  val width=((dm.widthPixels*factor).toInt()/2)*2
  val height=((dm.heightPixels*factor).toInt()/2)*2
  @Suppress("DEPRECATION") val mr=MediaRecorder()
  recorder=mr
  mr.setVideoSource(MediaRecorder.VideoSource.SURFACE)
  mr.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
  mr.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
  mr.setVideoSize(width,height); mr.setVideoFrameRate(30); mr.setVideoEncodingBitRate(8_000_000)
  mr.setOutputFile(descriptor!!.fileDescriptor); mr.prepare()
  val manager=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
  projection=manager.getMediaProjection(resultCode,data)
  callback=object:MediaProjection.Callback() { override fun onStop() { Handler(Looper.getMainLooper()).post { stopRecording() } } }
  projection!!.registerCallback(callback!!,Handler(Looper.getMainLooper()))
  display=projection!!.createVirtualDisplay("ScreenRecorder",width,height,dm.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,mr.surface,null,null)
  mr.start(); recording=true; paused=false; showBubble()
 }
 private fun pauseRecording() {
  if(recording && !paused) try { recorder?.pause(); paused=true; refreshBubble() } catch(e:Exception) { android.util.Log.e("Recorder","Pause failed",e) }
 }
 private fun resumeRecording() {
  if(recording && paused) try { recorder?.resume(); paused=false; refreshBubble() } catch(e:Exception) { android.util.Log.e("Recorder","Resume failed",e) }
 }
 private fun refreshBubble() {
  (bubble as? LinearLayout)?.let { panel ->
   (panel.getChildAt(0) as? TextView)?.text=if(paused) "▶ RESUME" else "Ⅱ PAUSE"
  }
 }
 private fun showBubble() {
  wm=getSystemService(WINDOW_SERVICE) as WindowManager
  val panel=LinearLayout(this).apply {
   orientation=LinearLayout.HORIZONTAL
   setBackgroundColor(Color.rgb(28,36,50))
  }
  val toggle=TextView(this).apply {
   text="Ⅱ PAUSE"; textSize=14f; setTextColor(Color.WHITE)
   setPadding(20,20,20,20)
   setOnClickListener { if(paused) resumeRecording() else pauseRecording() }
  }
  val stop=TextView(this).apply {
   text="■ STOP"; textSize=14f; setTextColor(Color.WHITE)
   setBackgroundColor(Color.rgb(220,48,65)); setPadding(20,20,20,20)
   setOnClickListener { stopRecording() }
  }
  panel.addView(toggle); panel.addView(stop)
  val params=WindowManager.LayoutParams(
   WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,
   WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
   WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT
  ).apply { gravity=Gravity.TOP or Gravity.END; x=20; y=180 }
  wm!!.addView(panel,params); bubble=panel
  panel.setOnTouchListener(object:View.OnTouchListener {
   var sx=0f; var sy=0f
   override fun onTouch(v:View,event:MotionEvent):Boolean {
    when(event.action) {
     MotionEvent.ACTION_DOWN -> { sx=event.rawX; sy=event.rawY; return true }
     MotionEvent.ACTION_MOVE -> {
      val dx=(event.rawX-sx).toInt(); val dy=(event.rawY-sy).toInt()
      params.x-=dx; params.y+=dy
      wm?.updateViewLayout(panel,params); sx=event.rawX; sy=event.rawY; return true
     }
    }
    return false
   }
  })
 }
 private fun stopRecording() {
  bubble?.let { try { wm?.removeView(it) } catch(_:Exception) {} }; bubble=null
  try { display?.release() } catch(_:Exception) {}; display=null
  try { if(recording) recorder?.stop() } catch(_:Exception) {}
  try { recorder?.reset(); recorder?.release() } catch(_:Exception) {}; recorder=null
  try { callback?.let { projection?.unregisterCallback(it) } } catch(_:Exception) {}
  callback=null; try { projection?.stop() } catch(_:Exception) {}; projection=null
  try { descriptor?.close() } catch(_:Exception) {}; descriptor=null
  output?.let { uri -> try { val values=android.content.ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING,0) }; contentResolver.update(uri,values,null,null) } catch(_:Exception) {} }; output=null
  recording=false; paused=false; stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
 }
 override fun onDestroy() { if(recording || output!=null) stopRecording(); super.onDestroy() }
}
