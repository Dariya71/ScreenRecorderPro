# Screen Recorder Pro (Android, no root)

An Android Studio Kotlin project, minimum Android 10 (API 29).

## Build
1. Install Android Studio with JDK 17 and Android SDK 35.
2. Open the `ScreenRecorderPro` folder.
3. Wait for Gradle sync (requires internet for dependencies).
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Find APK at `app/build/outputs/apk/debug/app-debug.apk`.

## Use
- Open app, press Start, grant overlay permission if requested, press Start again, and approve Android screen capture.
- Use the floating PAUSE/RESUME and STOP controls. Videos save to Movies/ScreenRecorderPro. Drag the dark background to reposition the controls.
- The notification has a Stop action as backup.

## Limitations
- Android consent required for each recording session. Protected FLAG_SECURE/DRM surfaces cannot be captured.
- Video only: pause/resume supported through MediaRecorder (API 29+); no audio or automatic split yet.
- Output size is bounded by device storage and device stability. Recording orientation is fixed at start.
- If Android force-kills the process or MediaRecorder fails, the MP4 may be incomplete.
- On some Android versions the floating bubble itself may be visible in the video.
- This is source code, not a compiled or tested binary; validate on a physical Android device before relying on it.
